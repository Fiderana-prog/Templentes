const section = shallowRef(0);

export function useCurrentSection() {
  return section;
}

export function useIcons() {
  return useState('svg-icons', () => ({}));
}
